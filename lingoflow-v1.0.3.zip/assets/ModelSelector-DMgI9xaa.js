import{c as i,j as e,g as u}from"./client-DfSyaHMG.js";/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=i("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=i("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=i("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=i("Languages",[["path",{d:"m5 8 6 6",key:"1wu5hv"}],["path",{d:"m4 14 6-6 2-3",key:"1k1g8d"}],["path",{d:"M2 5h12",key:"or177f"}],["path",{d:"M7 2h1",key:"1t2jsx"}],["path",{d:"m22 22-5-10-5 10",key:"don7ne"}],["path",{d:"M14 18h6",key:"1m8k6r"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=i("PenLine",[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z",key:"ymcmye"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=i("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=i("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=i("Sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=i("Star",[["polygon",{points:"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2",key:"8f66p6"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=i("WandSparkles",[["path",{d:"m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",key:"ul74o6"}],["path",{d:"m14 7 3 3",key:"1r5n42"}],["path",{d:"M5 6v4",key:"ilb8ba"}],["path",{d:"M19 14v4",key:"blhpug"}],["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M7 8H3",key:"zfb6yr"}],["path",{d:"M21 16h-4",key:"1cnmox"}],["path",{d:"M11 3H9",key:"1obp7u"}]]);/**
 * @license lucide-react v0.378.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=i("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),E=(t="dark")=>t==="light"?{card:"bg-white border-slate-200 text-slate-800 shadow-[0_20px_60px_rgba(0,0,0,0.12)]",bar:"bg-slate-300",title:"text-slate-800 hover:text-slate-950",pill:"bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700",iconBtn:"text-slate-400 hover:text-slate-700 hover:bg-slate-100",origBox:"bg-slate-50 border-slate-200 text-slate-600",subText:"text-slate-400",resText:"text-slate-900",menu:"bg-white border-slate-200 shadow-xl text-slate-700",menuItem:"text-slate-700 hover:bg-slate-100",menuActive:"bg-indigo-50 text-indigo-700 font-semibold"}:{card:"bg-slate-900 border-slate-700/80 text-slate-100 shadow-[0_20px_60px_rgba(0,0,0,0.6)] ring-1 ring-white/10",bar:"bg-slate-600/70",title:"text-slate-200 hover:text-white",pill:"bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/60 text-slate-200",iconBtn:"text-slate-400 hover:text-slate-200 hover:bg-slate-800",origBox:"bg-slate-950/60 border-slate-800/80 text-slate-400",subText:"text-slate-500",resText:"text-slate-100",menu:"bg-slate-900 border-slate-700 shadow-xl text-slate-300",menuItem:"text-slate-300 hover:bg-slate-800",menuActive:"bg-indigo-600/40 text-indigo-200 font-semibold"},G=["English","Vietnamese","Japanese","Korean","Chinese","French","Spanish","German"],x=({variant:t="primary",size:s="md",children:l,icon:r,className:n=""})=>{const d={sm:"px-2 py-0.5 text-xs gap-1",md:"px-2.5 py-1 text-xs gap-1.5"}[s],a={primary:"bg-indigo-950/60 text-indigo-300 border-indigo-500/40",secondary:"bg-slate-800/80 text-slate-300 border-slate-700 shadow-sm",success:"bg-emerald-950/60 text-emerald-300 border-emerald-500/40",warning:"bg-amber-950/60 text-amber-300 border-amber-500/40",danger:"bg-rose-950/60 text-rose-300 border-rose-500/40"}[t];return e.jsxs("span",{className:`inline-flex items-center font-medium rounded-full border backdrop-blur-md transition-all ${d} ${a} ${n}`,children:[r&&e.jsx("span",{className:"inline-flex shrink-0",children:r}),e.jsx("span",{children:l})]})},p={improve:"English",rewrite:"English",summary:"Vietnamese",translate:"Vietnamese"},c="engchat_target_languages",k=()=>{var t;return typeof chrome<"u"?(t=chrome.storage)==null?void 0:t.local:void 0},_=async()=>{var t,s;try{const l=(s=await((t=k())==null?void 0:t.get(c)))==null?void 0:s[c];return{...p,...l&&typeof l=="object"?l:{}}}catch{return{...p}}},D=async t=>{var s;try{await((s=k())==null?void 0:s.set({[c]:t}))}catch{}},b=[{id:"gemini-3.5-flash-lite",name:"Gemini 3.5 Flash-Lite",tag:"Recommended - Ultra fast",tagVariant:"success",description:"Ultra-low latency, quota efficient, and instant responses for chat and translation.",icon:e.jsx(j,{size:16,className:"text-emerald-400"})},{id:"gemini-3.5-flash",name:"Gemini 3.5 Flash",tag:"High quality",tagVariant:"primary",description:"Deep contextual reasoning, vocabulary lookup, and precise wording.",icon:e.jsx(y,{size:16,className:"text-indigo-400"})},{id:"gemini-3.1-flash-lite",name:"Gemini 3.1 Flash-Lite",tag:"Stable",tagVariant:"secondary",description:"A lightweight, stable model for everyday emails and messages.",icon:e.jsx(M,{size:16,className:"text-blue-400"})},{id:"gemini-2.5-flash",name:"Gemini 2.5 Flash",tag:"Standard",tagVariant:"secondary",description:"A standard model generation with high reliability and consistency.",icon:e.jsx(v,{size:16,className:"text-slate-400"})}],V=({language:t,selectedModel:s,onSelectModel:l})=>{var d;const r=u(t||"en"),n={"gemini-3.5-flash-lite":["model.recommended","model.flashLiteDescription"],"gemini-3.5-flash":["model.highQuality","model.flashDescription"],"gemini-3.1-flash-lite":["model.stable","model.stableDescription"],"gemini-2.5-flash":["model.standard","model.standardDescription"]};return e.jsxs("section",{className:"flex flex-col gap-5 border-t border-slate-800/80 pt-6 first:border-t-0 first:pt-0",children:[e.jsxs("div",{className:"flex items-center justify-between gap-3",children:[e.jsxs("h3",{className:"flex items-center gap-2 text-base font-semibold text-slate-100",children:[e.jsx(y,{size:16,className:"text-indigo-400"})," ",r("model.title")]}),e.jsx(x,{variant:"primary",size:"sm",children:((d=b.find(a=>a.id===s))==null?void 0:d.name)||s})]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:b.map(a=>{var g,m;const o=s===a.id;return e.jsxs("div",{role:"button",tabIndex:0,onClick:()=>l(a.id),onKeyDown:h=>{(h.key==="Enter"||h.key===" ")&&(h.preventDefault(),l(a.id))},className:`p-3.5 rounded-xl border cursor-pointer transition-all duration-300 text-left flex flex-col justify-between gap-2.5 relative ${o?"bg-indigo-500/10 border-indigo-400/80 ring-1 ring-indigo-400/30":"bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60"}`,children:[e.jsxs("div",{className:"flex items-start justify-between gap-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:"p-1.5 rounded-lg bg-slate-900 border border-slate-800 shrink-0",children:a.icon}),e.jsx("span",{className:`text-xs font-bold ${o?"text-indigo-200":"text-slate-200"}`,children:a.name})]}),e.jsxs("div",{className:"flex items-center gap-1.5 shrink-0",children:[e.jsx(x,{variant:a.tagVariant,size:"sm",children:r(((g=n[a.id])==null?void 0:g[0])||"model.standard")}),o&&e.jsx("div",{className:"w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center shrink-0 shadow-sm",children:e.jsx(f,{size:12,strokeWidth:3})})]})]}),e.jsx("p",{className:"text-xs text-slate-400 leading-relaxed line-clamp-2",children:r(((m=n[a.id])==null?void 0:m[1])||"model.standardDescription")})]},a.id)})})]})};export{x as B,f as C,p as D,N as F,b as G,L,V as M,S as P,y as S,T as W,G as a,z as b,A as c,v as d,E as g,_ as l,D as s};
